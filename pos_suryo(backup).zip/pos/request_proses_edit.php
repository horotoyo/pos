<?php
include 'koneksi.php';

$ID 		= $_POST['id'];
$table		= $_POST['table'];
$item		= $_POST['item'];
$qty		= $_POST['qty'];

$sql3		= "SELECT item.price as price FROM item WHERE item.id=$item";
$result3 	= mysqli_query($connect, $sql3);
$row3 		= mysqli_fetch_assoc($result3);
$price		= $row3['price'];

$total		= $price*$qty;

$sql4 = "UPDATE request SET table_number = '$table', item_id = '$item', qty = '$qty', total = '$total' WHERE id = '$ID'";
mysqli_query($connect,$sql4);
header('location:request.php');
?>